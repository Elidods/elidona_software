
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
using namespace std;

// Book class
class Book {
public:
    string title;
    string author;
    int pages;
    string id;
    bool borrowed;

    // Constructor
    Book(string t, string a, int p, string i, bool b) {
        title = t;
        author = a;
        pages = p;
        id = i;
        borrowed = b;
    }

    // Display book information
    void display() {
        cout << "\nBook ID: " << id;
        cout << "\nTitle: " << title;
        cout << "\nAuthor: " << author;
        cout << "\nPages: " << pages;
        cout << "\nStatus: "
             << (borrowed ? "Borrowed" : "Available");
        cout << "\n---------------------------\n";
    }
};

// Function to read books from file
vector<Book> loadBooks(string filename) {
    vector<Book> books;
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cout << "Error opening bookData.txt\n";
        return books;
    }

    while (getline(file, line)) {
        stringstream ss(line);

        string title, author, pagesText, id, status;

        if (getline(ss, title, ',') &&
            getline(ss, author, ',') &&
            getline(ss, pagesText, ',') &&
            getline(ss, id, ',') &&
            getline(ss, status)) {

            try {
                int pages = stoi(pagesText);
                bool borrowed = (status == "true");

                books.emplace_back(
                    title, author, pages, id, borrowed
                );
            }
            catch (...) {
                cout << "Invalid book record skipped.\n";
            }
        }
    }

    file.close();
    return books;
}

// Function to search for a book by ID
int findBook(vector<Book>& books, string id) {
    for (int i = 0; i < static_cast<int>(books.size()); i++) {
        if (books[i].id == id)
            return i;
    }

    return -1;
}

int main() {
    vector<Book> books = loadBooks("bookData.txt");

    if (books.empty()) {
        cout << "No books loaded. Check bookData.txt.\n";
        return 1;
    }

    int choice;

    do {
        cout << "\n===== LIBRARY BOOK MANAGER =====\n";
        cout << "1. View all books\n";
        cout << "2. View individual book\n";
        cout << "3. Borrow a book\n";
        cout << "4. Return a book\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";

        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            choice = 0;
        }

        if (choice == 1) {
            for (Book& book : books)
                book.display();
        }
        else if (choice >= 2 && choice <= 4) {
            string id;

            cout << "Enter book ID: ";
            cin >> id;

            int index = findBook(books, id);

            if (index == -1) {
                cout << "Book not found.\n";
            }
            else if (choice == 2) {
                books[index].display();
            }
            else if (choice == 3) {
                if (books[index].borrowed) {
                    cout << "Book is already borrowed.\n";
                }
                else {
                    books[index].borrowed = true;
                    cout << "Book borrowed successfully.\n";
                }
            }
            else if (choice == 4) {
                if (!books[index].borrowed) {
                    cout << "Book is already available.\n";
                }
                else {
                    books[index].borrowed = false;
                    cout << "Book returned successfully.\n";
                }
            }
        }
        else if (choice != 5) {
            cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 5);

    cout << "\nThank you for using the Library Manager.\n";

    return 0;
}
