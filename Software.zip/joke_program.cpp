
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <random>
using namespace std;

// Function to read jokes from the text file
vector<string> loadJokes(string filename) {
    vector<string> jokes;
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cout << "Error: Cannot open randomJokes.txt\n";
        return jokes;
    }

    while (getline(file, line)) {
        if (!line.empty())
            jokes.push_back(line);
    }

    file.close();
    return jokes;
}

int main() {
    vector<string> jokes = loadJokes("randomJokes.txt");

    if (jokes.empty()) {
        cout << "No jokes available.\n";
        return 1;
    }

    random_device rd;
    mt19937 generator(rd());

    string request;

    cout << "===== ALEXA JOKE PROGRAM =====\n";
    cout << "Type: Alexa, tell me a joke\n";
    cout << "Type quit to exit.\n";

    while (true) {
        cout << "\nEnter your request: ";
        getline(cin, request);

        if (request == "quit" || request == "QUIT" ||
            request == "Quit")
            break;

        if (request != "Alexa, tell me a joke") {
            cout << "Please use the specified request.\n";
            continue;
        }

        uniform_int_distribution<int> distribution(
            0, static_cast<int>(jokes.size()) - 1
        );

        string joke = jokes[distribution(generator)];

        size_t separator = joke.find('?');

        if (separator == string::npos) {
            cout << "Invalid joke format.\n";
            continue;
        }

        string setup = joke.substr(0, separator + 1);
        string punchline = joke.substr(separator + 1);

        cout << "\n" << setup << "\n";
        cout << "Press Enter to reveal the punchline...";
        
        string pause;
        getline(cin, pause);

        cout << "\nPunchline: " << punchline << "\n";
    }

    cout << "\nThank you for using the Joke Program!\n";

    return 0;
}
