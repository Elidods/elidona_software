
#include <iostream>
#include <iomanip>
#include <string>
#include <limits>
#include <cctype>
using namespace std;

// Function to get journey distance in miles
double getDistance() {
    double distance;

    do {
        cout << "Enter journey distance in miles: ";
        cin >> distance;

        if (cin.fail() || distance <= 0) {
            cout << "Please enter a valid positive distance.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            distance = 0;
        }
    } while (distance <= 0);

    return distance;
}

// Function to get fuel type
string getFuelType() {
    string fuel;

    do {
        cout << "Enter fuel type (petrol/diesel): ";
        cin >> fuel;

        for (char &ch : fuel)
            ch = static_cast<char>(tolower(ch));

        if (fuel != "petrol" && fuel != "diesel")
            cout << "Invalid fuel type. Try again.\n";

    } while (fuel != "petrol" && fuel != "diesel");

    return fuel;
}

// Function to calculate CO2 emissions
double calculateEmissions(double distance, string fuel) {
    const double consumption = 9.66;
    double emissionFactor;

    if (fuel == "diesel")
        emissionFactor = 2.68;
    else
        emissionFactor = 2.31;

    double litres = (distance * consumption) / 100.0;
    return litres * emissionFactor;
}

int main() {
    cout << "===== CAR CO2 CALCULATOR =====\n\n";

    double distance = getDistance();
    string fuel = getFuelType();

    double result = calculateEmissions(distance, fuel);

    cout << fixed << setprecision(2);
    cout << "\n===== CALCULATION RESULT =====\n";
    cout << "Distance: " << distance << " miles\n";
    cout << "Fuel type: " << fuel << "\n";
    cout << "Estimated CO2 emissions: "
         << result << " kg\n";

    return 0;
}
